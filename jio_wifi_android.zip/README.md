# Jio Wi-Fi Controller - Native Android App

A native Android application built with **Kotlin**, **Material Design 3**, and **OkHttp** to control JioFiber Wi-Fi networks (2.4 GHz and 5 GHz) directly from an Android phone.

---

## Features
- **Individual Band Selection**: Checkboxes for **2.4 GHz (AP 1)** and **5 GHz (AP 4)** to toggle either band separately or both together.
- **Check Wi-Fi Status**: Live status query against `http://192.168.29.1` that displays whether each band is ON or OFF.
- **Auto-Remember Credentials**: Remembers your router IP, username, and password across app launches.
- **Forced Login Handling**: Automatically bypasses active session locks (`tf1_forcedLoginForm`) if another browser session was left open.
- **Cleartext HTTP Permitted**: Configured with `network_security_config.xml` to allow communication with the local router gateway on Android 9+.

---

## Project Structure
```text
jio_wifi_android/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/jiocontrol/app/
│       │   ├── MainActivity.kt        # UI controller & event handlers
│       │   └── JioRouterApi.kt        # OkHttp router API client (TeamF1 platform.cgi)
│       └── res/
│           ├── layout/
│           │   └── activity_main.xml  # Material 3 mobile layout
│           ├── values/
│           │   ├── colors.xml
│           │   ├── strings.xml
│           │   └── themes.xml
│           └── xml/
│               └── network_security_config.xml # Allows HTTP to 192.168.29.1
├── build.gradle.kts
└── settings.gradle.kts
```

---

## How to Build the APK

### In Android Studio
1. Open **Android Studio**.
2. Select **File &rarr; Open...** and choose this folder:  
   `C:\Users\pulak\.gemini\antigravity\scratch\jio_wifi_android`
3. Wait for Gradle to sync.
4. Click **Build &rarr; Build Bundle(s) / APK(s) &rarr; Build APK(s)**.
5. Transfer the generated `.apk` file to your phone and install it.

---

## ⚠️ Important Note on Mobile Wi-Fi Control
* When your phone is connected to the router's **2.4 GHz** Wi-Fi, you can freely turn OFF the **5 GHz** band without losing connection.
* If you turn OFF **both bands**, your phone will immediately disconnect from the router and switch to mobile data. Because mobile data cannot reach `192.168.29.1`, you will need to turn Wi-Fi back ON using your PC (connected via Ethernet LAN) or by rebooting the router.
