package com.jiocontrol.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class WifiStatusResult(
    val ap1Status: String, // "ON" or "OFF"
    val ap4Status: String  // "ON" or "OFF"
)

class JioRouterApi {

    private val cookieStore = HashMap<String, List<Cookie>>()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .cookieJar(object : CookieJar {
            override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
                cookieStore[url.host] = cookies
            }

            override fun loadForRequest(url: HttpUrl): List<Cookie> {
                return cookieStore[url.host] ?: ArrayList()
            }
        })
        .build()

    suspend fun authenticate(ip: String, user: String, pass: String, logCallback: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val loginUrl = "http://$ip/platform.cgi"
            val formBody = FormBody.Builder()
                .add("thispage", "index.html")
                .add("users.username", user)
                .add("users.password", pass)
                .add("button.login.users.dashboard", "Login")
                .build()

            val request = Request.Builder()
                .url(loginUrl)
                .post(formBody)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                .header("Referer", "http://$ip/platform.cgi?page=index.html")
                .build()

            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: ""

            if (html.contains("button.continue.index") || html.contains("tf1_forcedLoginForm")) {
                withContext(Dispatchers.Main) { logCallback("Existing session detected. Overriding...") }
                val overrideBody = FormBody.Builder()
                    .add("button.continue.index", "Continue")
                    .add("thispage", "index.html")
                    .add("tf1_hTmp1", "1")
                    .add("tf1_hTmp2", "1")
                    .add("loginSession.username", user)
                    .build()

                val overrideReq = Request.Builder()
                    .url(loginUrl)
                    .post(overrideBody)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    .header("Referer", "http://$ip/platform.cgi?page=index.html")
                    .build()

                client.newCall(overrideReq).execute()
            }

            true
        }

    suspend fun getWifiStatus(ip: String, user: String, pass: String, logCallback: (String) -> Unit): WifiStatusResult =
        withContext(Dispatchers.IO) {
            authenticate(ip, user, pass, logCallback)

            val apUrl = "http://$ip/platform.cgi?page=accessPoints.html"
            val request = Request.Builder()
                .url(apUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                .header("Referer", "http://$ip/platform.cgi?page=index.html")
                .build()

            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: ""

            val ap1On = html.contains("<tr class=\"gradeA\" id=\"1\" status=\"1\">")
            val ap4On = html.contains("<tr class=\"gradeA\" id=\"4\" status=\"1\">")

            WifiStatusResult(
                ap1Status = if (ap1On) "ON" else "OFF",
                ap4Status = if (ap4On) "ON" else "OFF"
            )
        }

    suspend fun toggleWifi(
        ip: String,
        user: String,
        pass: String,
        targetApIds: List<String>,
        enable: Boolean,
        logCallback: (String) -> Unit
    ): WifiStatusResult = withContext(Dispatchers.IO) {
        authenticate(ip, user, pass, logCallback)

        // Step 1: Fetch accessPoints.html to extract hidden form token
        val apUrl = "http://$ip/platform.cgi?page=accessPoints.html"
        val apReq = Request.Builder()
            .url(apUrl)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
            .header("Referer", "http://$ip/platform.cgi?page=index.html")
            .build()

        val apResp = client.newCall(apReq).execute()
        val apHtml = apResp.body?.string() ?: ""

        var token = ""
        val tokenMatcher = Pattern.compile("id=\"tf1_form_hid_token\"\\s+value=\"([^\"]+)\"").matcher(apHtml)
        if (tokenMatcher.find()) {
            token = tokenMatcher.group(1) ?: ""
        }

        val action = if (enable) "enable" else "disable"

        // Step 2: Submit toggle for each selected AP ID
        for (apId in targetApIds) {
            val name = if (apId == "1") "2.4 GHz" else "5 GHz"
            withContext(Dispatchers.Main) { logCallback("Submitting '$action' command for $name (AP$apId)...") }

            val toggleBody = FormBody.Builder()
                .add("thispage", "accessPoints.html")
                .add("accessPoints.checkbox", apId)
                .add("button.$action.accessPoints.accessPoints", action)
                .add("token", token)
                .build()

            val postReq = Request.Builder()
                .url("http://$ip/platform.cgi")
                .post(toggleBody)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                .header("Referer", "http://$ip/platform.cgi?page=accessPoints.html")
                .build()

            client.newCall(postReq).execute()
        }

        // Step 3: Wait 2 seconds and fetch updated status
        kotlinx.coroutines.delay(2000)
        getWifiStatus(ip, user, pass, logCallback)
    }
}
