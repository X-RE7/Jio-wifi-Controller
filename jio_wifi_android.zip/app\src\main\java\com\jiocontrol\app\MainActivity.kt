package com.jiocontrol.app

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jiocontrol.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val routerApi = JioRouterApi()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSavedPreferences()

        binding.btnStatus.setOnClickListener {
            checkStatus()
        }

        binding.btnOn.setOnClickListener {
            toggleSelected(enable = true)
        }

        binding.btnOff.setOnClickListener {
            toggleSelected(enable = false)
        }
    }

    private fun loadSavedPreferences() {
        val prefs = getSharedPreferences("JioWifiPrefs", Context.MODE_PRIVATE)
        binding.etIp.setText(prefs.getString("ip", "192.168.29.1"))
        binding.etUser.setText(prefs.getString("user", "admin"))
        binding.etPassword.setText(prefs.getString("pass", "Pulak@2490"))
    }

    private fun savePreferences() {
        val prefs = getSharedPreferences("JioWifiPrefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("ip", binding.etIp.text.toString().trim())
            .putString("user", binding.etUser.text.toString().trim())
            .putString("pass", binding.etPassword.text.toString().trim())
            .apply()
    }

    private fun log(message: String) {
        val time = timeFormat.format(Date())
        binding.tvLog.append("[$time] $message\n")
        binding.logScrollView.post {
            binding.logScrollView.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun setBanner(text: String, colorType: String) {
        binding.tvStatusBanner.text = "Status: $text"
        when (colorType) {
            "SUCCESS" -> {
                binding.tvStatusBanner.setBackgroundColor(Color.parseColor("#DCF5E1"))
                binding.tvStatusBanner.setTextColor(Color.parseColor("#14641E"))
            }
            "ERROR" -> {
                binding.tvStatusBanner.setBackgroundColor(Color.parseColor("#FFE6E6"))
                binding.tvStatusBanner.setTextColor(Color.parseColor("#A01919"))
            }
            "WARN" -> {
                binding.tvStatusBanner.setBackgroundColor(Color.parseColor("#FFF5D7"))
                binding.tvStatusBanner.setTextColor(Color.parseColor("#8C5A0A"))
            }
            else -> {
                binding.tvStatusBanner.setBackgroundColor(Color.parseColor("#E1EBFA"))
                binding.tvStatusBanner.setTextColor(Color.parseColor("#283C5A"))
            }
        }
    }

    private fun setUIBusy(busy: Boolean) {
        binding.btnOn.isEnabled = !busy
        binding.btnOff.isEnabled = !busy
        binding.btnStatus.isEnabled = !busy
        binding.chk24.isEnabled = !busy
        binding.chk50.isEnabled = !busy
    }

    private fun checkStatus() {
        savePreferences()
        val ip = binding.etIp.text.toString().trim()
        val user = binding.etUser.text.toString().trim()
        val pass = binding.etPassword.text.toString().trim()

        setUIBusy(true)
        setBanner("Checking Wi-Fi status...", "INFO")
        log("Checking router status on $ip...")

        lifecycleScope.launch {
            try {
                val status = routerApi.getWifiStatus(ip, user, pass) { log(it) }
                binding.chk24.text = "2.4 GHz (AP 1): ${status.ap1Status}"
                binding.chk50.text = "5 GHz (AP 4): ${status.ap4Status}"
                log("Current Status -> 2.4 GHz: ${status.ap1Status} | 5 GHz: ${status.ap4Status}")

                if (status.ap1Status == "ON" && status.ap4Status == "ON") {
                    setBanner("Wi-Fi is ON (Both 2.4G & 5G)", "SUCCESS")
                } else if (status.ap1Status == "OFF" && status.ap4Status == "OFF") {
                    setBanner("Wi-Fi is OFF (Both Disabled)", "WARN")
                } else {
                    setBanner("2.4G is ${status.ap1Status} | 5G is ${status.ap4Status}", "INFO")
                }
            } catch (e: Exception) {
                log("Error: ${e.message}")
                setBanner("Error: ${e.message}", "ERROR")
            } finally {
                setUIBusy(false)
            }
        }
    }

    private fun toggleSelected(enable: Boolean) {
        savePreferences()
        val ip = binding.etIp.text.toString().trim()
        val user = binding.etUser.text.toString().trim()
        val pass = binding.etPassword.text.toString().trim()

        val targets = ArrayList<String>()
        if (binding.chk24.isChecked) targets.add("1")
        if (binding.chk50.isChecked) targets.add("4")

        if (targets.isEmpty()) {
            log("No band selected. Check 2.4 GHz and/or 5 GHz.")
            setBanner("Please select 2.4 GHz or 5 GHz", "WARN")
            return
        }

        val stateStr = if (enable) "ON" else "OFF"
        setUIBusy(true)
        setBanner("Turning selected bands $stateStr...", "INFO")
        log("Initiating Turn $stateStr command...")

        lifecycleScope.launch {
            try {
                val updatedStatus = routerApi.toggleWifi(ip, user, pass, targets, enable) { log(it) }
                binding.chk24.text = "2.4 GHz (AP 1): ${updatedStatus.ap1Status}"
                binding.chk50.text = "5 GHz (AP 4): ${updatedStatus.ap4Status}"
                log("Verified: 2.4 GHz is ${updatedStatus.ap1Status} | 5 GHz is ${updatedStatus.ap4Status}")
                setBanner("Completed: 2.4G is ${updatedStatus.ap1Status} | 5G is ${updatedStatus.ap4Status}", "SUCCESS")
            } catch (e: Exception) {
                log("Error: ${e.message}")
                setBanner("Error: ${e.message}", "ERROR")
            } finally {
                setUIBusy(false)
            }
        }
    }
}
